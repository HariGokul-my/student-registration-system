let submitBtn = document.getElementById("submit");

const info = {
    student_name: '',
    Studentid: '',
    class: '',
    rollno: '', // Fix this to be 'url' to match later usage in showData
    gender: '',
    skillArr: [],
}

const getData = () => {
    info.student_name = document.getElementById('name').value;
    info.email = document.getElementById('email').value;
    info.url = document.getElementById('url').value; // Set 'url' instead of 'image'
    info.website = document.getElementById('website').value;
    info.gender = document.querySelector('input[name="male-female"]:checked').value;

    let skills = document.querySelectorAll('.checkbox:checked');
    info.skillArr = [];
    skills.forEach((item) => {
        info.skillArr.push(item.value);
    });

    // Retrieve and update local storage
    let infoItem = localStorage.getItem("infoSection") ? JSON.parse(localStorage.getItem("infoSection")) : [];
    infoItem.push(info);
    localStorage.setItem("infoSection", JSON.stringify(infoItem));
}

const showData = () => {
    let cardContainer = document.getElementById("cardContainer");
    let cards = '';

    let getLocalStorage = localStorage.getItem("infoSection");
    if (getLocalStorage === null) {
        console.log("No data found in localStorage");
    } else {
        let cardDivArr = JSON.parse(getLocalStorage);
        cardDivArr.forEach((item, index) => {
            cards += `<div class="card">
                
                <div class="info">
                    <p><strong>Name</strong>: ${item.student_name}</p>
                    <p><strong>studentid</strong>: ${item.email}</p>
                    <p><strong>Email</strong>: ${item.website}</p>
                    <p><strong>Contact_no</strong>: ${item.url}</p>
                    <p><strong>Gender</strong>: ${item.gender}</p>
                    <p><strong>Skills</strong>: ${item.skillArr.join(", ")}</p>
                    <button onclick="deleteData(${index})">Delete</button>
                </div>
            </div>`;
        });
    }
    cardContainer.innerHTML = cards;
}

const deleteData = (index) => {
    let getList = JSON.parse(localStorage.getItem("infoSection"));
    getList.splice(index, 1);
    localStorage.setItem("infoSection", JSON.stringify(getList));
    showData(); // Refresh the display without reloading
}
showData();

submitBtn.addEventListener('click', () => {
    getData();
    showData();
});